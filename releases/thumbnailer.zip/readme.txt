=== Thumbnailer ===
Contributors: thumbnailer
Tags: images, thumbnail, pdf, postscript
Requires at least: 5.6
Tested up to: 6.5
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Thumbnail generator for WordPress that works with various file formats including PDF and PostScript.

== Description ==

Thumbnailer integrates the Thumbnailer library into WordPress, allowing thumbnail generation from various file formats including images, PDF, and PostScript files.

**Features:**

* Generate thumbnails from PDF and PostScript files
* Resize images in the browser
* Configure which posts should use the thumbnailer functionality

== Installation ==

1. Upload the `thumbnailer` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings > Thumbnailer to configure which posts should use the thumbnailer

== Frequently Asked Questions ==

= How do I enable the thumbnailer on specific posts? =

Go to Settings > Thumbnailer and enter the post IDs (comma-separated) where you want the thumbnailer to be active.

= What file formats are supported? =

The thumbnailer supports standard image formats (JPEG, PNG, GIF), PDF, and PostScript files.

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release
